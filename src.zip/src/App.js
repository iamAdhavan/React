import React from 'react';
import './App.css';
import { BrowserRouter as Router , Routes , Route } from 'react-router-dom';
import Login from './Login'
import Minmax from './Minmax'

function App() {
  return (
    
     <div> 
      <Router>
      <Routes>
      <Route path = '/' element = {<Login/>}></Route>
      <Route path = '/Minmax' element = {<Minmax/>}></Route>
      </Routes>
      </Router>
    </div>
  );
}

export default App;
